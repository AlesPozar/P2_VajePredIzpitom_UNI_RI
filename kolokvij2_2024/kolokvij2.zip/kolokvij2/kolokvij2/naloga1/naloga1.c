
/*
 * Prevajanje in zagon testnega programa testXY.c:
 *
 * gcc -Dtest testXY.c naloga1.c
 * ./a.out
 *
 * Zagon testne skripte ("sele potem, ko ste prepri"cani, da program deluje!):
 *
 * export name=naloga1
 * make test
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "naloga1.h"
//5min, 1. try

//=============================================================================

// po potrebi dopolnite ...

void nastavi(Vozlisce* zacetek) {
    // dopolnite ...
    Vozlisce* prejsno = zacetek;
    zacetek->prejsnje = NULL;
    while(zacetek->naslednje != NULL){
        zacetek = zacetek->naslednje;
        zacetek->prejsnje = prejsno;
        prejsno = prejsno->naslednje;
    }
}

//=============================================================================

#ifndef test

int main() {
    // "Ce "zelite funkcijo <nastavi> testirati brez testnih primerov,
    // dopolnite to funkcijo in prevedite datoteko na obi"cajen na"cin 
    // (gcc naloga1.c).
    return 0;
}

#endif
