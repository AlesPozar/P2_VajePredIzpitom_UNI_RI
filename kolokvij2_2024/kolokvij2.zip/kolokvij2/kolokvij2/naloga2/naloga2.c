
/*
 * Zagon testne skripte ("sele potem, ko ste prepri"cani, da program deluje!):
 *
 * export name=naloga2
 * make test
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

// po potrebi dopolnite ...
int main(int argc, char** argv) {
    // dopolnite ...
    int stPodanihAtr = argc - 4;
    FILE* input = fopen(argv[1], "r");
    FILE* output = fopen(argv[2], "w");
    int stVsehAtr = atoi(argv[3]);
    char atributi[stPodanihAtr][101];
    for(int i = 4; i < argc; i++){
        strcpy(atributi[i-4], argv[i]);
    }

    /*for(int i = 0; i < argc - 4; i++){
        printf("%s\n", atributi[i]);
    }
    printf("\n");*/

    int stolpZaIzpis[stPodanihAtr];
    char line[100*102];
    fgets(line, 100*102, input);
    char vhodniPod[stVsehAtr][101];
    int stevnikPod = 0, stevVpisa = 0;

    printf("%s\n", line);
    for(int i = 0; i < strlen(line); i++){
        if(line[i] == ' ' || line[i] == '\n'){
            vhodniPod[stevnikPod][stevVpisa] = '\0';
            stevVpisa = 0;
            stevnikPod++;
        }
        else{
            vhodniPod[stevnikPod][stevVpisa] = line[i];
            stevVpisa++;
        }
    }
    printf("%s\n", vhodniPod[0]);
    printf("%s\n", vhodniPod[1]);
    printf("%s\n", vhodniPod[2]);
    printf("%s\n", vhodniPod[3]);
    printf("%s+++\n", vhodniPod[4]);
    for(int i = 0; i < stVsehAtr; i++){//indeks i gre od 0 do 5, brez 5
        printf("%s++", vhodniPod[i]);
    }

    printf("\n");

    int izpisStolpPoVr[stPodanihAtr];
    for(int i = 0; i < stPodanihAtr; i++){
        for(int y = 0; y < stVsehAtr; y++){
            if(strcmp(atributi[i], vhodniPod[y]) == 0){
                izpisStolpPoVr[i] = y;
            }
        }
    }

    for(int i = 0; i < stPodanihAtr; i++){
        printf("%d   ", izpisStolpPoVr[i]);
    }

    printf("\n");

    return 0;
}
